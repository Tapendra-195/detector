import numpy as np
from numpy import loadtxt
import matplotlib.pyplot as plt
import math
import string
import sys
from scipy.optimize import curve_fit

def linearFunc(x,intercept,slope):
      y = intercept + slope * x
      return y


#reading in data
data=[]
f = open("alldata.txt", "r")
for x in f:
      filename,N,mean,sd,fwhm,energy = x.split() #filename, N, mean, SD, FWHM, energy
      error = float(sd)/math.sqrt(float(N)) #calculating error
      data.append([filename,float(N),float(mean),float(sd),float(fwhm),float(energy),float(error)])


#Plotting energy(keV) vs channel(mean)
data=np.array(data)
print(data)
xdata =  np.asarray(data[:, 5]).astype(float)
ydata = np.asarray(data[:, 2]).astype(float)
d_y = np.asarray(data[:, 6]).astype(float)
print(xdata)
print(ydata)
print("error = ")
print(d_y)
#plt.plot(data[:,1], data[:,1], 'o')
#plt.show()
a_fit,cov=curve_fit(linearFunc,xdata,ydata,sigma=d_y,absolute_sigma=True)

#outputs
inter = a_fit[0] #intercept
slope = a_fit[1] #slope
d_inter = np.sqrt(cov[0][0]) #error intercept
d_slope = np.sqrt(cov[1][1]) #error slope

f = open("fitparameters.txt", "w")
f.write("m = "+str(slope)+"\n")
f.write("d_m = "+str(d_slope)+"\n")
f.write("c = "+str(inter)+"\n")
f.write("d_c = "+str(d_inter)+"\n")
f.close()

# Create a graph showing the data.
plt.errorbar(xdata,ydata,yerr=d_y,fmt='r.',label='Data')

# Compute a best fit line from the fit intercept and slope.
yfit = inter + slope*xdata

# Create a graph of the fit to the data. We just use the ordinary plot
# command for this.
plt.plot(xdata,yfit,label='Fit [slope= ' +str(round(slope,2))+ ', c= '+str(round(inter,2))+' +- '+str(round(d_inter,2))+']')

# Display a legend, label the x and y axes and title the graph.
plt.legend()
plt.xlabel('Energy(keV)')
plt.ylabel('channels')

# Save the figure to a file
plt.savefig('DataPlot_with_error.png',dpi=300)


#second plot
plt.clf()
sd = np.asarray(data[:, 3]).astype(float)
sd = sd/slope
plt.plot(xdata,sd,'o')
plt.xlabel('Energy(keV)')
plt.ylabel('sd(keV)')
plt.savefig("plotsd.png")
exit()
