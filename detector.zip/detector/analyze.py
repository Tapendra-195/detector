import numpy as np
from numpy import loadtxt
import matplotlib.pyplot as plt
import math
import string
import sys

def mean(frequency,start_X, end_X):
        sum=0
        N = 0
        for i in range(start_X,end_X+1):
                N += frequency[i]
                sum += i*frequency[i]
        return sum/N
        
def standard_dev(frequency,mean,start_X, end_X):
        sum=0
        N = 0
        for i in range(start_X,end_X+1):
                N += frequency[i]
                sum += (i-mean)*(i-mean)*frequency[i]
        return math.sqrt(sum/N)


#main part


if len(sys.argv) > 1:
        filename =sys.argv[1]
else:
        print("./analyze filename")
        exit()
        
#read text file into NumPy array
frequency = loadtxt(filename+'_histo.dat')
#printing the data into the list
print(frequency)
print(len(frequency))
X=[]
for i in range (8192):
        X.append(i)
                
        
counts, edges, plot = plt.hist(X,bins=8192, range = [0,8191],weights=frequency)
plt.title('Voltage vs Counts ('+filename+')')
plt.xlabel('Voltage')
plt.ylabel('Counts')
plt.ylim(0, max(counts)+10)#(6245, 6270)#(485, 510)

plt.savefig(filename+'_normal_plot.png')
#plt.ylim(0, 8000)
print(counts)

print('Zoom in:')
loop=True
while loop:
        try:
                start_X = int(input("Enter x_low: "))
                end_X = int(input("Enter x_high: "))
        except ValueError:
                print("Invalid input. Please enter an integer.")
                
        print('Start_x = , ' + str(start_X))
        print('end_x = , ' + str(end_X))


        plt.xlim(start_X, end_X)#(6245, 6270)#(485, 510)
        plt.ylim(0, max(counts[start_X:end_X])+10)#(6245, 6270)#(485, 510)
        #plt.show()
        
        #Mean and sd calculation
        #start_X =489 #6245#489
        #end_X = 507#6270#507
        x_bar = mean(frequency,start_X,end_X)
        print("mean = " + str(x_bar))
        sd = standard_dev(frequency,x_bar,start_X,end_X)
        print("Standard deviation = "+ str(sd))
        fwhm = 2.3548*sd
        print("FWHM = 2.3548*sd = " + str(fwhm))
        plt.savefig(filename+'_zoomed_plot.png')

        #print(counts[start_X:end_X])
        N = np.sum(counts[start_X:end_X]) #Total counts from start_X to end_X
        print("N = " + str(N))
        
        loop = input('Done ? [y/n] :').lower()!='y'
        print('\n')
        
#save data to file
f = open(filename+".txt", "w")
f.write("N \t mean \t SD \t FWHM \n")
f.write(str(N)+"\t"+str(x_bar) + "\t" + str(sd) + "\t" + str(fwhm))
f.close()
exit()
