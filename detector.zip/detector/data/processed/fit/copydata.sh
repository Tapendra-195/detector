#!/bin/bash
input="./filename"
while read line
do
#    echo $line
    input1="./$line"
    while read line1
    do
        echo $line1
    done<"$input1"
    echo "$line $line1" >> alldata.txt
done<"$input"
