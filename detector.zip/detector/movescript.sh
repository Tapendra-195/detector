#!/bin/bash
text=$1.txt
text_n=$1_$2.txt
normal=$1_normal_plot.png
normal_n=$1_$2_normal_plot.png
zoomed=$1_zoomed_plot.png
zoomed_n=$1_$2_zoomed_plot.png
echo $text
mv $text ./data/processed/$text_n
echo $normal
mv $normal ./data/processed/$normal_n
echo $zoomed
mv $zoomed ./data/processed/$zoomed_n
#echo $name $1 $2
